import json
import os
import uuid
import boto3
import requests
from datetime import datetime, timedelta
from requests_auth_aws_sigv4 import AWSSigV4
import random

session = boto3.session.Session()
client = session.client("healthlake")

dataStoreEndpoint = os.environ.get('data_store_endpoint', 'None')

def get_named_parameter(event, name):
    """
    Get a parameter from the lambda event
    """
    if name in event:
        return event[name]
    else:
        return None

def get_patient_emr(patientId):
    """
    Get/Read a single patient resource
    
    Args:
        patientId (string): Identifier for the patient
    """
    resourcePath = 'Patient'
    fhirQuery = dataStoreEndpoint + resourcePath + '/' + patientId

    auth = AWSSigV4("healthlake", session=session)

    print("FHIR Endpoint: ", fhirQuery)

    r = requests.get(fhirQuery, auth=auth)
    return r.json()

def search_patient_emr(addressState):
    """
    Search patients resources by state
    
    Args:
        addressState (string): Value of state based on which patients need to be searched
    """
    resourcePath = 'Patient'
    fhirQuery = dataStoreEndpoint + resourcePath + '/_search'

    auth = AWSSigV4("healthlake", session=session)

    print("FHIR Endpoint: ", fhirQuery)

    #r = requests.get(fhirQuery, auth=auth)
    r = requests.post(fhirQuery, data={'address-state':addressState}, auth=auth, headers={'Content-Type':'application/x-www-form-urlencoded'})
    return r.json()

def search_immunization_emr(searchValue, searchParam = 'patient'):
    """
    Search immunization records for a given patient
    
    Args:
        searchParam (string): Name of search parameter. Currently patient is the only valid value
        searchValue (string): Value of search parameter.
    """
    resourcePath = 'Immunization'
    fhirQuery = dataStoreEndpoint + resourcePath + "/_search"

    auth = AWSSigV4("healthlake", session=session)

    print("FHIR Endpoint: ", fhirQuery)
    r = requests.post(fhirQuery, data={searchParam:searchValue}, auth=auth, headers={'Content-Type':'application/x-www-form-urlencoded'})
    return r.json()

def get_available_slots(dateString):
    """
    Get the details of available appointments slots around the provided datetime
    
    Args:
        date_string: desired date of appointment (yyyy-mm-dd format)
    """

    datetime_object = datetime.strptime(dateString, "%Y-%m-%d")

    #Get doctor's schedule
    resourcePath = 'Practitioner'
    fhirQuery = dataStoreEndpoint + resourcePath + "/_search"

    auth = AWSSigV4("healthlake", session=session)

    print("FHIR Endpoint: ", fhirQuery)
    r = requests.post(fhirQuery, data={"_count":1}, auth=auth, headers={'Content-Type':'application/x-www-form-urlencoded'}).json()

    doctor_details = {}
    if 'entry' in r:
        if len(r['entry']) > 0:
            doctor_details = r['entry'][0]['resource']

    return {
        "doctor_details": doctor_details,
        "available_slots":[
            (datetime_object + timedelta(days=random.choice([-2, -1, 0, 1, 2])) + timedelta(hours=random.randint(9, 17))).isoformat(),
            (datetime_object + timedelta(days=random.choice([-2, -1, 0, 1, 2])) + timedelta(hours=random.randint(9, 17))).isoformat(),
            (datetime_object + timedelta(days=random.choice([-2, -1, 0, 1, 2])) + timedelta(hours=random.randint(9, 17))).isoformat()
        ]
    }

def book_appointment(dateString):
    """
    Book the appointment as per preferred date time
    
    Args:
        date_string: desired date of appointment (yyyy-mm-dd hh:mm format)
    """

    #datetime_object = datetime.strptime(dateString, "%Y-%m-%d %H:%M")

    return {
        "messsage": f"Appointment for the slot dated {dateString} has been booked with confirmation number: {random.randint(10000,20000)}"
    }

def lambda_handler(event, context):
    print(f"Event: {event}")

    resource = get_named_parameter(event, 'resource')
    httpMethod = get_named_parameter(event, 'httpMethod')
    requestBody = get_named_parameter(event, 'body')
    queryStringParameters = get_named_parameter(event, 'queryStringParameters')

    print(f"Resource: {resource}, requestBody: {requestBody}, queryStringParameters: {queryStringParameters}")

    if resource == '/get_patient_emr' and httpMethod == 'GET':
        patient_id = get_named_parameter(queryStringParameters, 'patient_id')

        if patient_id:
            patientRecord = get_patient_emr(patientId = patient_id)
            responseBody = {'body': {'patientRecord': patientRecord}}
        else:
            responseBody = {'body': 'Missing patient_id parameter'}
    elif resource == '/search_patient_emr' and httpMethod == 'POST':
        address_state = get_named_parameter(json.loads(requestBody), 'address_state')

        if address_state:
            searchResults = search_patient_emr(addressState = address_state)
            responseBody = {'body': {'searchRecords': searchResults}}
        else:
            responseBody = {'body': 'Missing address_state parameter'}
    elif resource == '/search_immunization_emr' and httpMethod == 'POST':
        search_value = get_named_parameter(json.loads(requestBody), 'search_value')

        if search_value:
            searchResults = search_immunization_emr(searchValue = search_value)
            responseBody = {'body': {'searchRecords': searchResults}}
        else:
            responseBody = {'body': 'Missing search_value parameter'}
    elif resource == '/get_available_slots' and httpMethod == 'GET':
        date_string = get_named_parameter(queryStringParameters, 'date_string')

        if date_string:
            slotResults = get_available_slots(dateString = date_string)
            responseBody = {'body': {'searchRecords': slotResults}}
        else:
            responseBody = {'body': 'Missing date_string parameter'}
    elif resource == '/book_appointment' and httpMethod == 'POST':
        date_string = get_named_parameter(json.loads(requestBody), 'date_string')

        if date_string:
            apptConfirmation = book_appointment(dateString = date_string)
            responseBody = {'body': {'confirmation': apptConfirmation}}
        else:
            responseBody = {'body': 'Missing date_string parameter'}

    else:
        responseBody = {'body': 'Invalid resource or httpMethod'}

    res = {
        "isBase64Encoded": False,
        "statusCode": 200,
        "headers": {
            "Content-Type": "*/*"
        },
        "body": json.dumps(responseBody)
    }

    print("Response: {}".format(res))

    return res
